your change passoword token = <?php echo e($token); ?>

<?php /**PATH D:\xampp\htdocs\Learnig_Project\vue\library_api\resources\views/auth/forget_mail.blade.php ENDPATH**/ ?>